@echo off
setlocal EnableExtensions EnableDelayedExpansion 

>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Request Adminitrator Privilege
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "cmd.exe", "/c """"%~f0""""", "", "runas", 0 >> "%temp%\getadmin.vbs"
    echo Run getadmin.vbs	
    "%temp%\getadmin.vbs"
    echo Delete getadmin.vbs
    del "%temp%\getadmin.vbs" >nul 2>&1
    exit /b
)

echo Run as Administartor
cd /d "%~dp0"

certutil -f -addstore root tusimpleBI.cer
certutil -f -addstore CA tusimpleBI.cer
certutil -f -addstore TrustedPublisher tusimpleBI.cer

if %ERRORLEVEL% equ 0 (
    echo [成功] 证书已安装到 "%STORE_NAME%" 存储区。
) else (
    echo [失败] 证书安装失败，错误码: %ERRORLEVEL%。
    pause
    exit /b 1
)

reg add HKCU\SOFTWARE\Kingsoft\Office\ET\AddinsWL /v tusimpleBI /t REG_SZ /d "" /f

install_files\setup.exe
